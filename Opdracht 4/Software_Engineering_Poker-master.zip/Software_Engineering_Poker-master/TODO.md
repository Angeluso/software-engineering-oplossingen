Als Raise gedaan wordt ==> Updaten van money en totalTableMoney ==> WERKT ENKEL MET BUTTON
Aanduiding wiens beurt het is ==> LUKT NIET
KAARTEN LIVE UPDATEN ==> LUKT NIET